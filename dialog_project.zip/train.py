import torch
from transformers import AutoTokenizer, GPT2LMHeadModel, DataCollatorForLanguageModeling
import re
from datasets import Dataset

from transformers.data import data_collator
from datasets import load_dataset

# 加载数据集并指定分隔符和列名
dataset = load_dataset(
    "csv",
    data_files={"train": "data/toy_train.txt", "test": "data/toy_valid.txt"},
    delimiter="\t",  # 指定制表符作为分隔符
    column_names=["text", "label"]  # 第一列是输入，第二列是标签
)

# 查看数据集内容
# print(dataset)
# print(dataset['train'][:5])
# print(dataset['test'][:5])
# 选择一个预训练模型的分词器，比如 BERT 或 GPT-2 的分词器
tokenizer = AutoTokenizer.from_pretrained("bert-base-chinese")

# 对训练集进行分词
def tokenize_function(example):
    return tokenizer(example["text"], padding="max_length", truncation=True)

# 对整个数据集应用分词
tokenized_datasets = dataset.map(tokenize_function, batched=True)

# 查看分词后的数据
print(tokenized_datasets)

# # 查看原始文本和对应的分词结果
# def show_tokenization(example):
#     # 获取原始文本
#     original_text = example["text"]
#     # 获取分词后的 token
#     tokenized_text = tokenizer.tokenize(example["text"])
#     return {"original_text": original_text, "tokenized_text": tokenized_text}
#
# # 对数据集应用这个查看分词效果的函数
# tokenized_with_original = dataset["train"].map(show_tokenization)
#
# # 查看前几条数据
# print(tokenized_with_original[:5])




