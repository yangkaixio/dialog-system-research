from transformers import AutoModelForCausalLM, AutoTokenizer
# 选择模型
MODEL_NAME = "gpt2"  # 可替换为 "EleutherAI/gpt-neo-1.3B" 或更大的模型

# 加载模型和分词器
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
# 初始化对话上下文
chat_history = ""

def chat_with_gpt(user_input, max_length=100, top_p=0.9, temperature=0.7):
    global chat_history
    chat_history += f"User: {user_input}\n"

    # 将上下文和用户输入编码为模型输入
    inputs = tokenizer.encode(chat_history + "AI:", return_tensors="pt")

    # 生成回复
    outputs = model.generate(
        inputs,
        max_length=len(inputs[0]) + max_length,
        top_p=top_p,
        temperature=temperature,
        pad_token_id=tokenizer.eos_token_id,
        do_sample=True,
    )

    # 解码回复并更新上下文
    reply = tokenizer.decode(outputs[0][len(inputs[0]):], skip_special_tokens=True)
    chat_history += f"AI: {reply}\n"
    return reply
if __name__ == "__main__":
    print("AI 对话系统已启动！输入 'exit' 退出对话。")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("再见！")
            break

        response = chat_with_gpt(user_input)
        print(f"AI: {response}")

