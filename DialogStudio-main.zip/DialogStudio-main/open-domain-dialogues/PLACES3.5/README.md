# PLACES: Prompting Language Models for Social Conversation Synthesis

A synthesizing a multi-party conversational dataset

# Citation:
```commandline
@inproceedings{chen2023places,
  title={PLACES: Prompting Language Models for Social Conversation Synthesis},
  author={Chen, Maximillian and Papangelis, Alexandros and Tao, Chenyang and Kim, Seokhwan and Rosenbaum, Andy and Liu, Yang and Yu, Zhou, and Hakkani-Tur, Dilek},
  booktitle={Findings of the Association for Computational Linguistics: EACL 2023},
  pages={to appear},
  year={2023}
}
```

