TOP is a Semantic Parsing for Task Oriented Dialog dataset. It collects a total of 44783 annotations with
25 intents and 36 slots, randomly split into 31279
training, 4462 validation and 9042 test utterances. The data is originally from the EMNLP 2018 work [Semantic Parsing for Task Oriented Dialog
using Hierarchical Representations](https://aclanthology.org/D18-1300.pdf)