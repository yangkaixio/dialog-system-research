# The ATIS (Airline Travel Information System) Dataset

The ATIS dataset is formatted based on [ATIS_dataset](https://github.com/howl-anderson/ATIS_dataset), we follow  [Few-Shot-Intent-Detection](https://github.com/jianguoz/Few-Shot-Intent-Detection) to split 500 examples from 'train' into the 'validation' set. You can merge 'validation' back to 'train' if you don't need the validation set. 

