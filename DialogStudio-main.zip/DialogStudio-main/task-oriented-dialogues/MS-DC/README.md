# Introduction
MS-DC is a human-annotated conversational data in three domains (movie-ticket booking, restaurant reservation, and taxi booking).


The dataset has been used  for the [Microsoft Dialogue Challenge](https://github.com/xiul-msr/e2e_dialog_challenge). Please cite their work if you use the dataset.